<?php

namespace App\Http\Controllers;

use App\members;
use App\CsvData;
use App\Http\Requests\CsvImportRequest;
use Illuminate\Http\Request; 
use Maatwebsite\Excel\Facades\Excel;
use Gate;

class add_memberController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function importMem()
    {
        if(!Gate::allows('isAdmin')){
        abort(404,"sorry cannot access this page");
      }
        return view('add_member');
    }

  public function parseImport(CsvImportRequest $request)
{

    $path = $request->file('csv_file')->getRealPath();

    if ($request->has('header')) {
        $data = Excel::load($path, function($reader) {})->get()->toArray();
    } else {
        $data = array_map('str_getcsv', file($path));
    }

    if (count($data) > 0) {
        if ($request->has('header')) {
            $csv_header_fields = [];
            foreach ($data[0] as $key => $value) {
                $csv_header_fields[] = $key;
            }
        }
        $csv_data = array_slice($data, 0, 2);

        $csv_data_file = CsvData::create([
            'csv_filename' => $request->file('csv_file')->getClientOriginalName(),
            'csv_header' => $request->has('header'),
            'csv_data' => json_encode($data)
        ]);
    } else {
        return redirect()->back();
    }

    return view('import_field', compact( 'csv_header_fields', 'csv_data', 'csv_data_file'));

}

public function processImport(Request $request)
{
    $data = CsvData::find($request->csv_data_file_id);
    $csv_data = json_decode($data->csv_data, true);
    foreach ($csv_data as $row) {
        $members = new members();
        foreach (config('app.data_fields') as $index => $field) {
            if ($data->csv_header) {
                $members->$field = $row[$request->fields[$field]];
            } else {
                $members->$field = $row[$request->fields[$index]];
            }
        }
        $members->save();
    }

    return view('add_member');
}


    
}
?>