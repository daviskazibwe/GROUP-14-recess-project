<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class members extends Model
{
    public $fillable = ['member_name', 'date_of_enrollment', 'gender','recommender'];
}
