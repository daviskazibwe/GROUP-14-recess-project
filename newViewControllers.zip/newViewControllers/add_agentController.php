<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class add_agentController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function regAgent()
    {
        return view('add_agent');
    }
}
